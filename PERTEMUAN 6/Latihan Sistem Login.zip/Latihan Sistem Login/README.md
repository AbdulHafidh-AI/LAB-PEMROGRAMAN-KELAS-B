### HOW TO RUN THIS APP❓
<hr>
<b>1. COMPILE THIS PROGRAM</b> ⚡
<pre><code> $ gcc -Wall -pedantic -g -0 run App.c </code></pre>
<b>2. RUN THIS PROGRAM ^_^</b>
<pre><code> $ ./run admin root </code></pre>


### DATABASE
<hr>
<ul>
  <li>Username: admin </li>
  <li>Password: root </li>
 </ul>

### WARNING⚠️
<hr>
If a login process is terminated, Maybe there is something wrong in writing an argument or the argument that you input is less than 3 or bigger than 3.

<h3 align="left"><b>PROGRAMMING LANGUAGE:</b></h3>
<hr>
<a href="https://www.cprogramming.com/" target="_blank"> <img src="https://raw.githubusercontent.com/devicons/devicon/master/icons/c/c-original.svg" alt="c" width="40" height="40"/> </a> 
</p>

### LISENCE ⚠️
<hr>
<b>THIS SOURCE CODE IS NOT FOR SALE 😠<b>


